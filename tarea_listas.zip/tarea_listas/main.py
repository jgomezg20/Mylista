from pasajero import Pasajero
from mi_lista import MiLista
from lista_python import ListaPython

lista1 = MiLista(10)
lista2 = ListaPython()


# ------------------------- funciones de apoyo -------------------------
def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("  Debe ser un número entero.")


def leer_pasajero():
    numero = leer_entero("  N.º de pasajero: ")
    nombre = input("  Nombre: ").strip()
    cedula = input("  Cédula: ").strip()
    edad = leer_entero("  Edad: ")
    fecha = input("  Fecha de vuelo (AAAA-MM-DD): ").strip()
    destino = input("  Destino: ").strip()
    asiento = input("  Asiento: ").strip().upper()
    return Pasajero(numero, nombre, cedula, edad, fecha, destino, asiento)


def cargar_datos_prueba(lista):
    lista.añadir(Pasajero(1005, "Diana", "0923456789", 22, "2026-11-15", "Quito",  "12A"))
    lista.añadir(Pasajero(1002, "Ana",   "0912345678", 28, "2026-11-15", "Lima",   "03C"))
    lista.añadir(Pasajero(1009, "Luis",  "0987654321", 35, "2026-11-20", "Bogotá", "18F"))
    lista.añadir(Pasajero(1004, "Beto",  "0934567890", 16, "2026-11-20", "Quito",  "07B"))
    lista.añadir(Pasajero(1001, "Elena", "0901234567", 41, "2026-11-22", "Lima",   "01A"))
    print("  ✓ Datos de prueba cargados")


def mostrar_opciones(titulo, extras=False):
    print(f"\n========== {titulo} ==========")
    print(" 1. Añadir           2. Listar            3. Insertar en posición")
    print(" 4. Buscar (lineal)  5. Buscar (binaria)  6. Modificar")
    print(" 7. Eliminar por posición                 8. Eliminar por número")
    print(" 9. Ordenar asc     10. Ordenar desc     11. Reversar")
    print("12. Copiar          13. Longitud")
    if extras:
        print("14. Filtrar por destino                  15. Mayores de edad")
    print(" C. Cargar datos de prueba                0. Volver")


def mostrar_busqueda(lista, posicion):
    """Muestra el resultado de una búsqueda (lineal o binaria)."""
    if posicion == -1:
        print("  No existe")
    else:
        # Se obtiene el pasajero con la posición encontrada
        if isinstance(lista, MiLista):
            encontrado = lista.datos[posicion]
        else:
            encontrado = lista.pasajeros[posicion]
        print(f"  Encontrado en [{posicion}]: {encontrado.nombre}")


def ejecutar_opcion(lista, op):
    """Ejecuta las opciones comunes 1-13 y C, siguiendo LEER -> LLAMAR -> MOSTRAR.
    Devuelve True si la opción fue atendida."""
    if op == "1":                                       # Añadir
        pasajero = leer_pasajero()                      # 1. LEER
        if lista.añadir(pasajero):                      # 2. LLAMAR
            print("  ✓ Pasajero añadido")              # 3. MOSTRAR

    elif op == "2":                                     # Listar
        lista.listar()

    elif op == "3":                                     # Insertar en posición
        posicion = leer_entero("  Posición: ")
        pasajero = leer_pasajero()
        if lista.insertar(posicion, pasajero):
            print(f"  ✓ Pasajero insertado en [{posicion}]")

    elif op == "4":                                     # Buscar (lineal)
        numero = leer_entero("  N.º de pasajero a buscar: ")
        mostrar_busqueda(lista, lista.buscar(numero))

    elif op == "5":                                     # Buscar (binaria)
        numero = leer_entero("  N.º de pasajero a buscar: ")
        print("  (recuerda: la búsqueda binaria requiere la lista ordenada con la opción 9)")
        mostrar_busqueda(lista, lista.buscar_binaria(numero))

    elif op == "6":                                     # Modificar
        numero = leer_entero("  N.º de pasajero a modificar: ")
        destino = input("  Nuevo destino: ").strip()
        asiento = input("  Nuevo asiento: ").strip().upper()
        if lista.modificar(numero, destino, asiento):
            print("  ✓ Pasajero modificado")
        else:
            print("  No existe")

    elif op == "7":                                     # Eliminar por posición
        posicion = leer_entero("  Posición a eliminar: ")
        eliminado = lista.eliminar_por_posicion(posicion)
        if eliminado is not None:
            print(f"  Eliminado: {eliminado.nombre}; quedan {lista.longitud()}")

    elif op == "8":                                     # Eliminar por número
        numero = leer_entero("  N.º de pasajero a eliminar: ")
        if lista.eliminar_por_valor(numero):
            print(f"  ✓ Pasajero {numero} eliminado; quedan {lista.longitud()}")
        else:
            print("  No existe")

    elif op == "9":                                     # Ordenar ascendente
        lista.ordenar_asc()
        print("  ✓ Ordenada de menor a mayor")
        lista.listar()

    elif op == "10":                                    # Ordenar descendente
        lista.ordenar_desc()
        print("  ✓ Ordenada de mayor a menor")
        lista.listar()

    elif op == "11":                                    # Reversar
        lista.reversar()
        print("  ✓ Lista reversada")
        lista.listar()

    elif op == "12":                                    # Copiar
        copia = lista.copiar()
        copia.reversar()                                # se reversa SOLO la copia
        print("  Copia (reversada):")
        copia.listar()
        print("  Original (sin cambios):")
        lista.listar()

    elif op == "13":                                    # Longitud
        print(f"  Cantidad de pasajeros: {lista.longitud()}")

    elif op == "C":                                     # Datos de prueba
        cargar_datos_prueba(lista)

    else:
        return False
    return True


# ---------------------- MENÚ 1 · MiLista ----------------------
def menu_lista1():
    while True:
        mostrar_opciones("MENÚ 1 · MiLista")
        op = input("Opción: ").strip().upper()

        if op == "0":
            break
        if not ejecutar_opcion(lista1, op):
            print("  Opción no válida")


# ---------------------- MENÚ 2 · list de Python ----------------------
def menu_lista2():
    while True:
        mostrar_opciones("MENÚ 2 · list de Python", extras=True)
        op = input("Opción: ").strip().upper()

        if op == "14":                                  # solo Lista 2
            destino = input("  Destino a filtrar: ").strip()
            filtrados = lista2.filtrar_por_destino(destino)
            if not filtrados:
                print("  No hay pasajeros con ese destino")
            else:
                for p in filtrados:
                    print(f"  {p}")
        elif op == "15":                                # solo Lista 2
            mayores = lista2.mayores_de_edad()
            if not mayores:
                print("  No hay pasajeros mayores de edad")
            else:
                for p in mayores:
                    print(f"  {p}")
        elif op == "0":
            break
        elif not ejecutar_opcion(lista2, op):
            print("  Opción no válida")


# ---------------------- MENÚ PRINCIPAL ----------------------
def main():
    while True:
        print("\n===== TAREA LISTAS · PASAJEROS ✈ =====")
        print("1. Menú 1 · MiLista")
        print("2. Menú 2 · list de Python")
        print("3. Salir")
        op = input("Opción: ").strip()
        if op == "1":
            menu_lista1()
        elif op == "2":
            menu_lista2()
        elif op == "3":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()
